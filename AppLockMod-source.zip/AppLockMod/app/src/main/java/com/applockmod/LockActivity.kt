package com.applockmod

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView

class LockActivity : Activity() {
    companion object { const val EXTRA_PKG = "pkg" }

    private var web: WebView? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE)
        build()
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        build()
    }

    private fun dropWeb() {
        web?.let { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }
        web = null
    }

    private fun build() {
        val pkg = intent.getStringExtra(EXTRA_PKG) ?: run { finish(); return }
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { pkg }

        dropWeb()
        val w = Gate.create(this, "verify", label) {
            Guard.unlocked = pkg
            finish()
        }
        web = w
        setContentView(w)

        if (Store.faceEnabled(this) && Bio.canUse(this)) {
            Bio.prompt(this, "Yuzni tanish", {
                Guard.unlocked = pkg
                finish()
            }, {})
        }
    }

    override fun onPause() { super.onPause(); web?.onPause() }
    override fun onResume() { super.onResume(); web?.onResume() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    override fun onDestroy() {
        dropWeb()
        super.onDestroy()
    }
}
