package com.applockmod

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.os.Process
import android.os.SystemClock
import android.view.inputmethod.InputMethodManager

/** Qulflash qarori: qaysi ilova ochilganini ikkala kuzatuvchi (xizmat) shu yerga xabar qiladi. */
object Guard {
    @Volatile var unlocked: String? = null
    private val ignored = HashSet<String>()
    private var lastPkg: String? = null
    private var lastAt = 0L

    fun refreshIgnored(c: Context) {
        ignored.clear()
        ignored.add("com.android.systemui")
        try {
            val imm = c.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.enabledInputMethodList.forEach { ignored.add(it.packageName) }
        } catch (e: Exception) {}
    }

    @Suppress("DEPRECATION")
    fun usageOk(c: Context): Boolean = try {
        val ao = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName) ==
            AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) { false }

    fun onForeground(c: Context, pkg: String) {
        if (pkg == c.packageName || pkg in ignored) return
        if (pkg != unlocked) unlocked = null
        if (unlocked != pkg && pkg in Store.locked(c)) {
            val now = SystemClock.uptimeMillis()
            if (pkg == lastPkg && now - lastAt < 1200) return
            lastPkg = pkg
            lastAt = now
            try {
                c.startActivity(
                    Intent(c, LockActivity::class.java)
                        .putExtra(LockActivity.EXTRA_PKG, pkg)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_NO_ANIMATION or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP)
                )
            } catch (e: Exception) {}
        }
    }
}
