package com.applockmod

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/** Maxsus imkoniyatlarsiz ishlaydigan kuzatuvchi: "Foydalanish ma'lumotlari" ruxsati orqali. */
class WatchService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var lastTs = 0L

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { Guard.unlocked = null }
    }

    private val tick = object : Runnable {
        override fun run() {
            try { poll() } catch (e: Exception) {}
            h.postDelayed(this, 400)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Guard.refreshIgnored(this)
        startFg()
        registerReceiver(screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF))
        lastTs = System.currentTimeMillis()
        h.post(tick)
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        h.removeCallbacks(tick)
        try { unregisterReceiver(screenOff) } catch (e: Exception) {}
        super.onDestroy()
    }

    private fun startFg() {
        val ch = "applock"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "AppLock", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, ch)
            .setContentTitle("AppLock ishlayapti")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun poll() {
        if (!Guard.usageOk(this)) return
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = usm.queryEvents(now - 3000, now)
        val e = UsageEvents.Event()
        var pkg: String? = null
        var ts = 0L
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                pkg = e.packageName
                ts = e.timeStamp
            }
        }
        if (pkg != null && ts > lastTs) {
            lastTs = ts
            Guard.onForeground(this, pkg)
        }
    }
}
