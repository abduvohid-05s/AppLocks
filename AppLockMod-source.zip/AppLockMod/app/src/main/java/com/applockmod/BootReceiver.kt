package com.applockmod

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Guard.usageOk(c) && Store.locked(c).isNotEmpty()) {
            try { c.startForegroundService(Intent(c, WatchService::class.java)) } catch (e: Exception) {}
        }
    }
}
