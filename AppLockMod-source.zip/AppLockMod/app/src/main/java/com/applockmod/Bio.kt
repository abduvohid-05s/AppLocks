package com.applockmod

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal

/** Telefonning o'z yuz / barmoq izi tizimidan foydalanadi. */
object Bio {
    @SuppressLint("NewApi")
    @Suppress("DEPRECATION")
    fun canUse(c: Context): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        val m = c.getSystemService(BiometricManager::class.java) ?: return false
        return if (Build.VERSION.SDK_INT >= 30)
            m.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) ==
                BiometricManager.BIOMETRIC_SUCCESS
        else
            m.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS
    }

    @SuppressLint("NewApi")
    fun prompt(a: Activity, title: String, onOk: () -> Unit, onFail: () -> Unit) {
        if (Build.VERSION.SDK_INT < 28) { onFail(); return }
        val ex = a.mainExecutor
        val b = BiometricPrompt.Builder(a)
            .setTitle(title)
            .setNegativeButton("Parol bilan", ex) { _, _ -> onFail() }
        if (Build.VERSION.SDK_INT >= 30) {
            b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
        }
        b.build().authenticate(CancellationSignal(), ex,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult?) { onOk() }
                override fun onAuthenticationError(code: Int, msg: CharSequence?) { onFail() }
            })
    }
}
