package com.applockmod

import android.app.Activity
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private enum class S { GATE, LIST, SETTINGS }

    private var state = S.GATE
    private var authed = false
    private var changing = false
    private var external = false
    private var lastLeft = 0L
    private var web: WebView? = null
    private var pwOpen = false
    private var faceOpen = false
    private var prOpen = false

    private val REQ_IMG = 41
    private val GREEN = Color.parseColor("#00ff41")
    private val DIM = Color.parseColor("#0b6b22")
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ---------------- hayot sikli ----------------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE)
        showGate()
    }

    override fun onStart() {
        super.onStart()
        // Ilovadan chiqib 30 soniyadan keyin qaytsa, parol qayta so'raladi
        if (authed && !external && System.currentTimeMillis() - lastLeft > 30000) {
            authed = false
            showGate()
        }
    }

    override fun onStop() {
        super.onStop()
        lastLeft = System.currentTimeMillis()
    }

    override fun onResume() {
        super.onResume()
        external = false
        web?.onResume()
        if (state == S.LIST && authed) showList()
    }

    override fun onPause() {
        super.onPause()
        web?.onPause()
    }

    override fun onDestroy() {
        dropWeb()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (state) {
            S.SETTINGS -> showList()
            S.GATE -> if (changing) { changing = false; showSettings() } else finish()
            S.LIST -> finish()
        }
    }

    private fun dropWeb() {
        web?.let { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }
        web = null
    }

    // ---------------- parol oynasi (Matrix) ----------------
    private fun showGate() {
        state = S.GATE
        changing = false
        openGate(if (Store.hasPassword(this)) "verify" else "set")
    }

    private fun openGate(mode: String) {
        dropWeb()
        val w = Gate.create(this, mode, "AppLock") {
            authed = true
            if (mode == "set") toast("Parol saqlandi")
            if (changing) { changing = false; showSettings() } else showList()
        }
        web = w
        setContentView(w)
        if (mode == "verify" && Store.faceEnabled(this) && Bio.canUse(this)) {
            Bio.prompt(this, "Yuzni tanish", { authed = true; showList() }, {})
        }
    }

    // ---------------- umumiy ko'rinish yordamchilari ----------------
    private fun tv(t: String, size: Float): TextView = TextView(this).apply {
        text = t
        setTextSize(TypedValue.COMPLEX_UNIT_DIP, size)
        setTextColor(GREEN)
        typeface = Typeface.create("serif-monospace", Typeface.NORMAL)
    }

    private fun column(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
    }

    private fun page(title: String, gear: Boolean, back: Boolean): LinearLayout {
        val root = column()
        root.setBackgroundColor(Color.BLACK)
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(14), dp(12), dp(8))
        }
        if (back) {
            head.addView(tv("\u2039", 26f).apply {
                setPadding(dp(12), dp(4), dp(12), dp(4))
                setOnClickListener { onBackPressed() }
            })
        }
        head.addView(tv(title, 22f).apply {
            typeface = Typeface.create("serif-monospace", Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (gear) {
            head.addView(tv("\u2699\uFE0F", 26f).apply {
                setPadding(dp(12), dp(4), dp(12), dp(4))
                setOnClickListener { showSettings() }
            })
        }
        root.addView(head)
        val body = column()
        val sv = ScrollView(this)
        sv.addView(body)
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
        return body
    }

    private fun item(t: String, indent: Int = 0, onClick: () -> Unit): TextView {
        val v = tv(t, 16f)
        v.setPadding(dp(16), dp(14), dp(16), dp(14))
        v.background = GradientDrawable().apply {
            setStroke(dp(1), DIM)
            cornerRadius = dp(10).toFloat()
            setColor(Color.parseColor("#031208"))
        }
        v.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
            setMargins(dp(12 + indent), dp(5), dp(12), dp(5))
        }
        v.setOnClickListener { onClick() }
        return v
    }

    private fun note(t: String, indent: Int = 0): TextView {
        val v = tv(t, 13f)
        v.setTextColor(Color.parseColor("#3fa8e8"))
        v.setLineSpacing(0f, 1.3f)
        v.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
            setMargins(dp(16 + indent), dp(4), dp(16), dp(4))
        }
        return v
    }

    private fun serviceOn(): Boolean {
        val v = Settings.Secure.getString(contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return v.contains("$packageName/")
    }

    // ---------------- ilovalar ro'yxati ----------------
    private fun showList() {
        state = S.LIST
        dropWeb()
        val body = page("AppLock", gear = true, back = false)

        val usage = Guard.usageOk(this)
        if (!serviceOn() && !usage) {
            body.addView(item("1. Qulfni yoqish: foydalanish ma'lumotlariga ruxsat") {
                external = true
                try {
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS,
                        Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                }
            })
            body.addView(item("yoki: Maxsus imkoniyatlar xizmatini yoqish") {
                external = true
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
        }
        if (!Settings.canDrawOverlays(this)) {
            body.addView(item("2. Boshqa ilovalar ustida ko'rsatishga ruxsat") {
                external = true
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            })
        }
        if (usage) {
            try { startForegroundService(Intent(this, WatchService::class.java)) } catch (e: Exception) {}
        }

        val pm = packageManager
        val locked = Store.locked(this).toMutableSet()
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launch, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        for (ri in apps) {
            val pkg = ri.activityInfo.packageName
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(6), dp(16), dp(6))
            }
            row.addView(ImageView(this).apply { setImageDrawable(ri.loadIcon(pm)) },
                LinearLayout.LayoutParams(dp(40), dp(40)))
            row.addView(tv(ri.loadLabel(pm).toString(), 16f).apply { setPadding(dp(12), 0, dp(12), 0) },
                LinearLayout.LayoutParams(0, WRAP, 1f))
            val box = TextView(this).apply {
                gravity = Gravity.CENTER; textSize = 14f
                setTextColor(Color.parseColor("#001a05"))
            }
            paintBox(box, pkg in locked)
            row.addView(box, LinearLayout.LayoutParams(dp(20), dp(20)))
            row.setOnClickListener {
                if (pkg in locked) locked.remove(pkg) else locked.add(pkg)
                Store.setLocked(this, locked)
                paintBox(box, pkg in locked)
            }
            body.addView(row)
        }
    }

    private fun paintBox(b: TextView, on: Boolean) {
        b.text = if (on) "\u2713" else ""
        b.background = GradientDrawable().apply {
            setStroke(dp(2), GREEN)
            cornerRadius = dp(4).toFloat()
            setColor(if (on) GREEN else Color.TRANSPARENT)
        }
    }

    // ---------------- sozlamalar ----------------
    private fun showSettings() {
        state = S.SETTINGS
        dropWeb()
        val body = page("\u2699\uFE0F Sozlamalar", gear = false, back = true)

        // --- Parol sozlamalari ---
        val pwSub = column()
        val faceSub = column()

        val faceState = when {
            !Bio.canUse(this) -> "Holat: telefonda yuz/barmoq izi sozlanmagan"
            Store.faceEnabled(this) -> "Holat: yoqilgan"
            else -> "Holat: o'chirilgan"
        }
        faceSub.addView(note(faceState, 36))
        faceSub.addView(note("Telefoningizning o'z yuz tanish tizimi ishlatiladi. " +
            "Yuz mos kelmasa, paroldan foydalanasiz.", 36))
        faceSub.addView(item("Yuzni yoqish / ro'yxatdan o'tkazish", 24) { enableFace() })
        faceSub.addView(item("Yuzni almashtirish", 24) { replaceFace() })
        faceSub.addView(item("Yuzni o'chirish", 24) {
            Store.setFace(this, false)
            toast("Yuzni tanish o'chirildi")
            showSettings()
        })
        faceSub.visibility = if (faceOpen) View.VISIBLE else View.GONE

        pwSub.addView(item("Parolni o'zgartirish", 12) {
            changing = true
            openGate("set")
        })
        pwSub.addView(item("Yuzni tanish funksiyasi \u2935\uFE0F", 12) {
            faceOpen = !faceOpen
            faceSub.visibility = if (faceOpen) View.VISIBLE else View.GONE
        })
        pwSub.addView(faceSub)
        pwSub.visibility = if (pwOpen) View.VISIBLE else View.GONE

        body.addView(item("Parol sozlamalari \u2935\uFE0F") {
            pwOpen = !pwOpen
            pwSub.visibility = if (pwOpen) View.VISIBLE else View.GONE
        })
        body.addView(pwSub)

        // --- Maxfiylik ---
        val prSub = column()
        prSub.addView(item("Ilova icon rasmini almashtirish", 12) { pickIcon() })
        prSub.addView(note("Tanlangan rasm bilan bosh ekranga yangi AppLock ikonkasi qo'shiladi.", 24))
        prSub.visibility = if (prOpen) View.VISIBLE else View.GONE

        body.addView(item("Ilova maxfiylik sozlamalari \u2935\uFE0F") {
            prOpen = !prOpen
            prSub.visibility = if (prOpen) View.VISIBLE else View.GONE
        })
        body.addView(prSub)
    }

    // ---------------- yuzni tanish ----------------
    private fun openEnroll() {
        external = true
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startActivity(Intent(Settings.ACTION_BIOMETRIC_ENROLL))
            } else {
                startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
            }
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e: Exception) {}
        }
    }

    private fun enableFace() {
        if (!Bio.canUse(this)) {
            toast("Avval telefon sozlamalarida yuzingizni kiriting. Sozlamalar ochilmoqda.")
            openEnroll()
            return
        }
        Bio.prompt(this, "Yuzingizni tasdiqlang", {
            Store.setFace(this, true)
            toast("Yuzni tanish yoqildi")
            showSettings()
        }, { toast("Bekor qilindi") })
    }

    private fun replaceFace() {
        toast("Telefon sozlamalarida eski yuzni o'chirib, yangisini kiriting")
        external = true
        try { startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) }
        catch (e: Exception) { openEnroll() }
    }

    // ---------------- ikonka rasmi ----------------
    private fun pickIcon() {
        external = true
        try {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), REQ_IMG)
        } catch (e: Exception) { toast("Rasm tanlash ilovasi topilmadi") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc == REQ_IMG && res == RESULT_OK) data?.data?.let { makeShortcut(it) }
    }

    private fun loadSquare(uri: Uri, size: Int): Bitmap {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / (s * 2) >= size && o.outHeight / (s * 2) >= size) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        val b = contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o2) }!!
        val m = minOf(b.width, b.height)
        val sq = Bitmap.createBitmap(b, (b.width - m) / 2, (b.height - m) / 2, m, m)
        return Bitmap.createScaledBitmap(sq, size, size, true)
    }

    private fun makeShortcut(uri: Uri) {
        try {
            val bmp = loadSquare(uri, 192)
            val sm = getSystemService(ShortcutManager::class.java)
            val info = ShortcutInfo.Builder(this, "applock_custom")
                .setShortLabel("AppLock")
                .setIcon(Icon.createWithBitmap(bmp))
                .setIntent(Intent(this, MainActivity::class.java).setAction(Intent.ACTION_MAIN))
                .build()
            val pinned = sm.pinnedShortcuts.any { it.id == "applock_custom" }
            if (pinned) {
                sm.updateShortcuts(listOf(info))
                toast("Ikonka yangilandi")
            } else if (sm.isRequestPinShortcutSupported) {
                sm.requestPinShortcut(info, null)
                toast("Bosh ekranga qo'shishni tasdiqlang")
            } else {
                toast("Telefoningiz bunday ikonkani qo'llamaydi")
            }
        } catch (e: Exception) {
            toast("Rasmni yuklab bo'lmadi")
        }
    }
}
