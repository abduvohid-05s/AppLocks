package com.applockmod

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.view.accessibility.AccessibilityEvent

class LockService : AccessibilityService() {
    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { Guard.unlocked = null }
    }

    override fun onServiceConnected() {
        Guard.refreshIgnored(this)
        registerReceiver(screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        Guard.onForeground(this, pkg)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        try { unregisterReceiver(screenOff) } catch (e: Exception) {}
        super.onDestroy()
    }
}
