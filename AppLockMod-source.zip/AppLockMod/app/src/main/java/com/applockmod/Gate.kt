package com.applockmod

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.webkit.JavascriptInterface
import android.webkit.WebView

object Gate {
    @SuppressLint("SetJavaScriptEnabled")
    fun create(a: Activity, mode: String, label: String, onDone: (String) -> Unit): WebView {
        val w = WebView(a)
        w.setBackgroundColor(Color.BLACK)
        w.settings.javaScriptEnabled = true
        w.settings.allowFileAccess = false
        w.settings.allowContentAccess = false
        w.settings.mediaPlaybackRequiresUserGesture = false
        val br = Bridge(a, mode, label, onDone)
        br.web = w
        w.addJavascriptInterface(br, "Android")
        w.loadUrl("file:///android_asset/lock.html")
        return w
    }

    class Bridge(
        private val a: Activity,
        private val m: String,
        private val lbl: String,
        private val onDone: (String) -> Unit
    ) {
        var web: WebView? = null

        @JavascriptInterface fun mode(): String = m
        @JavascriptInterface fun label(): String = lbl

        @JavascriptInterface fun submit(pw: String): Boolean {
            val ok = Store.check(a, pw)
            if (ok) a.runOnUiThread { onDone("ok") }
            return ok
        }

        @JavascriptInterface fun save(pw: String): Boolean {
            if (!Store.validPw(pw)) return false
            Store.setPassword(a, pw)
            a.runOnUiThread { onDone("saved") }
            return true
        }

        @JavascriptInterface fun muted(): Boolean = Store.muted(a)
        @JavascriptInterface fun setMuted(v: Boolean) { Store.setMuted(a, v) }

        @JavascriptInterface fun face(): Boolean =
            m == "verify" && Store.faceEnabled(a) && Bio.canUse(a)

        @JavascriptInterface fun startFace() {
            a.runOnUiThread {
                web?.evaluateJavascript("faceState('scan')", null)
                Bio.prompt(a, "Yuzni tanish", { onDone("ok") },
                    { web?.evaluateJavascript("faceState('idle')", null) })
            }
        }
    }
}
