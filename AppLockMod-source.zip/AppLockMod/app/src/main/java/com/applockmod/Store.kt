package com.applockmod

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom

object Store {
    private fun p(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)

    private fun hash(pw: String, salt: ByteArray): String {
        val md = MessageDigest.getInstance("SHA-256")
        var d = salt + pw.toByteArray()
        repeat(20000) { d = md.digest(d) }
        return Base64.encodeToString(d, Base64.NO_WRAP)
    }

    // Klaviaturada mavjud belgilar (parol faqat shulardan iborat bo'ladi)
    fun validPw(s: String): Boolean =
        Regex("^[A-Za-z0-9@#\$%&_\\-+=/()*\":!?., ]{4,32}\$").matches(s)

    fun hasPassword(c: Context) = p(c).contains("hash")

    fun setPassword(c: Context, pw: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p(c).edit()
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", hash(pw, salt))
            .apply()
    }

    fun check(c: Context, pw: String): Boolean {
        val salt = Base64.decode(p(c).getString("salt", "") ?: "", Base64.NO_WRAP)
        return hash(pw, salt) == p(c).getString("hash", null)
    }

    fun locked(c: Context): Set<String> =
        HashSet(p(c).getStringSet("apps", emptySet()) ?: emptySet())

    fun setLocked(c: Context, s: Set<String>) {
        p(c).edit().putStringSet("apps", HashSet(s)).apply()
    }

    fun faceEnabled(c: Context) = p(c).getBoolean("face", false)
    fun setFace(c: Context, v: Boolean) { p(c).edit().putBoolean("face", v).apply() }

    fun muted(c: Context) = p(c).getBoolean("muted", false)
    fun setMuted(c: Context, v: Boolean) { p(c).edit().putBoolean("muted", v).apply() }
}
