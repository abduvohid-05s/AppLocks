AppLock (oddiy APK, root/Magisk kerak emas)
- Parol oynasi: app/src/main/assets/lock.html (Matrix dizayn, musiqa, klaviatura ovozi, yuz paneli).
- Ilova ochilganda ham, boshqa ilovalar qulflanganda ham bir xil oyna chiqadi.
- Sozlamalar (yuqori burchakdagi shesternya): parolni o'zgartirish, yuzni tanish, ikonka rasmi.
- Musiqa: sound.m4a ni app/src/main/assets/ ga qo'ysangiz o'sha chalinadi.
- Yig'ish: GitHub'ga yuklang -> Actions -> AppLock-apk artifact -> app-debug.apk
